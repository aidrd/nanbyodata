# output

## Output
```javascript
() => {
  const array = [
    {
    "id": "Go to J-STAGE",
    "id_jglobal": "Go to J-GLOBAL",
    "journal": "\u81e8\u5e8a\u795e\u7d4c\u5b66(Web)",
    "pyear": "2018",
    "title": "\u9996\u4e0b\u304c\u308a\u3092\u4e3b\u8a34\u3068\u3057\u305f\u30a2\u30ec\u30ad\u30b5\u30f3\u30c0\u30fc\u75c5\u306e1\u4f8b",
    "url": "https://www.jstage.jst.go.jp/article/clinicalneurol/58/3/58_cn-001116/_article/-char/ja",
    "url_img_jglobal": "<a href='https://jglobal.jst.go.jp/detail?JGLOBAL_ID=201802272638719813'><img src='https://pubcasefinder.dbcls.jp/static/images/logo_J-GLOBAL.png' alt='J-GLOBAL logo' style='width: 100px; height: auto;'></a>",
    "url_img_jstage": "<a href=\"https://www.jstage.jst.go.jp/article/clinicalneurol/58/3/58_cn-001116/_article/-char/ja\"><img src=\"https://pubcasefinder.dbcls.jp/static/images/logo_J-STAGE.png\" alt=\"J-STAGE logo\" style=\"width: 100px; height: auto;\"></a>",
    "url_jglobal": "https://jglobal.jst.go.jp/detail?JGLOBAL_ID=201802272638719813" }
  ];
  return array;
}
```
